#!/bin/bash


python clickbotv3.3.py +12093870389 doge &
python clickbotv3.3.py +19177256013 doge &
python clickbotv3.3.py +17604917740 doge &

sleep 10
python clickbotv3.3.py +19207770598 doge &
python clickbotv3.3.py +16822315419 doge &
python clickbotv3.3.py +16152086475 doge &

sleep 10
python clickbotv3.3.py +13144414238 doge &
python clickbotv3.3.py +19703165342 doge &
python clickbotv3.3.py +12342211391 doge &

sleep 10
python clickbotv3.3.py +14078158027 doge &
python clickbotv3.3.py +12192252110 doge &

sleep 10
python clickbotv3.3.py +14102045032 doge &
python clickbotv3.3.py +14433835817 doge &

sleep 10
python clickbotv3.3.py +12482203509 doge &
python clickbotv3.3.py +14702500391 doge &
python clickbotv3.3.py +14353744773 doge &

sleep 10
python clickbotv3.3.py +12086897252 doge &
python clickbotv3.3.py +12402492876 doge &
python clickbotv3.3.py +12542793283 doge &

sleep 10
python clickbotv3.3.py +13042204722 doge &
python clickbotv3.3.py +13043098169 doge &
python clickbotv3.3.py +14172338823 doge &

sleep 10
python clickbotv3.3.py +14703132264 doge &
python clickbotv3.3.py +14844964924 doge &
python clickbotv3.3.py +15402329474 doge &

sleep 10
python clickbotv3.3.py +15703626567 doge &
python clickbotv3.3.py +16099084002 doge &
python clickbotv3.3.py +16188036252 doge &

sleep 10
python clickbotv3.3.py +16263615423 doge &
python clickbotv3.3.py +17065148045 doge &
python clickbotv3.3.py +17408797316 doge &

sleep 10
python clickbotv3.3.py +17654166526 doge &
python clickbotv3.3.py +17852686838 doge &
python clickbotv3.3.py +18019806039 doge &

sleep 10
python clickbotv3.3.py +19068254595 doge &
python clickbotv3.3.py +19083123775 doge &
python clickbotv3.3.py +19194297828 doge &

sleep 10
python clickbotv3.3.py +19294706496 doge &
python clickbotv3.3.py +12705511952 doge &
python clickbotv3.3.py +13605726014 doge &

sleep 10
python clickbotv3.3.py +16788691220 doge &
python clickbotv3.3.py +16824982013 doge &
python clickbotv3.3.py +17155785886 doge &

sleep 10
python clickbotv3.3.py +17244908567 doge &
python clickbotv3.3.py +19014024769 doge &
python clickbotv3.3.py +19154656636 doge &

sleep 10
python clickbotv3.3.py +19417773364 doge &
python clickbotv3.3.py +13606776576 doge &
python clickbotv3.3.py +14092314354 doge &

sleep 10
python clickbotv3.3.py +15204282970 doge &
python clickbotv3.3.py +15635196371 doge &
python clickbotv3.3.py +12064260636 doge &

sleep 10
python clickbotv3.3.py +14302245949 doge &
python clickbotv3.3.py +15036638903 doge &
python clickbotv3.3.py +15172585573 doge &

sleep 10
python clickbotv3.3.py +15732507628 doge &
python clickbotv3.3.py +18049998433 doge &
python clickbotv3.3.py +18603598285 doge &

sleep 10
python clickbotv3.3.py +18622845484 doge &
python clickbotv3.3.py +19312368552 doge &
python clickbotv3.3.py +19809999433 doge &

sleep 100

sh 3bash.sh